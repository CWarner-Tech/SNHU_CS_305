package com.snhu.sslserver;


import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;



import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
public class SslServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SslServerApplication.class, args);
	}

}
//FIXME: Add route to enable check sum return of static data example:  String data = "Hello World Check Sum!";
@RestController
class ServerController{
	
	
	//Create a RESTful route to generate and return the required information
    @RequestMapping("/hash")

       public String generateChecksum() {
    	
    	//Define your first and last name
    	String firstName = "Courtney";
    	String lastName = "Warner";
    	
    	//Combine first and last name to form the data String
    	String data = firstName + " " + lastName;
    	//
    	try {
    		//initialize MessageDigest object with SHA-256 algorithm cipher
    		MessageDigest md = MessageDigest.getInstance("SHA-256");
    		
    		//Generate hash value for the data String
    		byte[] digest = md.digest(data.getBytes());
    		
    		//Convert hash value to hex
    		String hexString = bytesToHex(digest);
    		
    		//return data string and checksum value
    		return "data: " + data + "\nChecksum Value: " + hexString;
    	}
    	catch (NoSuchAlgorithmException e) {
    		//Handle NoSuchAlgorithm
    		e.printStackTrace();
    		return "Error generating Checksum: "+ e.getMessage();
    	}
    }
    	//Method to convert byte array to hex
    	private String bytesToHex(byte[] bytes){
    		StringBuilder hexString = new StringBuilder();
    		for(byte b : bytes) {
    			hexString.append(String.format("%02x", b));
    		}
    	
    	return hexString.toString(); 	
    }
    }
